from django.contrib import admin
from settings.models import Settings,Poster
admin.site.register(Settings)
admin.site.register(Poster)