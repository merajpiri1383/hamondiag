from django.contrib import admin
from authentication.models import User,PostInfo
admin.site.register(User)
admin.site.register(PostInfo)